<div id="footer-wrap">
<p id="legal">(c) Copyright <a href="#">Sadun Book Store</a>.</p>
	</div>